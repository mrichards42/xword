-- ============================================================================
-- XWord additions
--     This package is automatically loaded by XWord
-- ============================================================================

require 'xword.utils'
require 'xword.paths'
require 'xword.messages'
require 'xword.utf-8'

-- Require the scripts directory, including subdirs
xword.requiredir('', true)
